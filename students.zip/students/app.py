from flask import Flask, render_template
import sqlite3
import base64

app = Flask(__name__)

# DATABASE CONNECTION
conn = sqlite3.connect('week10.db')
conn.row_factory = sqlite3.Row
c = conn.cursor()


# GET CONVERTED BD FILE
studentList = []
c.execute('select * from Lab10')
list = c.fetchall()
for row in list:
    studentList.append(dict(row))
# print (studentList)


# HOME PAGE
@app.route('/')
def index():
    return render_template('index.html', title='Students')


# DISPLAY ALL STUDENTS PAGE
@app.route('/displayAll')
def displayAll():
    ids = []
    name = []
    city = []
    country = []
    link = []
    pairsList = []
    for student in studentList:
        ids.append(student['id'])
        name.append(student['Student'])
        city.append(student['City'])
        country.append(student['Country'])
        link.append(base64.b64decode(student['Link']).decode('utf-8'))
    pairsList.extend(zip(ids,name,city,country,link))
    print(pairsList)
    return render_template('displayAll.html', pairs=pairsList)


# FIND A STUDENT STUDENTS PAGE
@app.route('/find-student/')
def find():
    name = []
    link = []
    pairsList = []
    for student in studentList:
        name.append(student['Student'])
        link.append(base64.b64decode(student['Link']).decode('utf-8'))
    pairsList.extend(zip(name, link))
    return render_template('findStudent.html', search = pairsList)
    pass


c.close()
conn.close()

if __name__ == '__main__':
    app.run(debug=True)
