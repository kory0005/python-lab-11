from flask import Flask, render_template
import sqlite3

app = Flask(__name__)



# DATABASE CONNECTION
conn = sqlite3.connect('week10.db')
conn.row_factory = sqlite3.Row
c = conn.cursor()



# GET CONVERTED BD FILE
studentList = []
c.execute('select * from Lab10')
list = c.fetchall()
for row in list:
    studentList.append(dict(row))
    print (studentList)



# HOME PAGE
@app.route('/')
def index():
    return render_template('index.html', title = 'Students')



# DISPLAY ALL STUDENTS PAGE
@app.route('/students-list/')
def display():
    ids = []
    name = []
    city = []
    country = []
    # for student in studentList:
    #     ids.append(student['id'])
    #     name.append(student['Student'])
    #     city.append(student['City'])
    #     country.append(student['Country'])
    #     pairsList = zip(ids, name, city, country)
    return render_template('displayAll.html', pairs = pairsList)



# FIND A STUDENT STUDENTS PAGE
@app.route('/find-student/')
def find():
    return render_template('findStudent.html')

if __name__ == '__main__':
    app.run()
