import sqlite3
import base64
import webbrowser


# GET CONVERTED BD FILE
def converList():
    studentList = []
    a.execute('select * from Lab10')
    list = a.fetchall()
    for row in list:
        studentList.append(dict(row))
    return studentList